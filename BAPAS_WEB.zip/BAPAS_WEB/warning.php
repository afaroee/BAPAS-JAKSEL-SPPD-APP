<?php include 'frontend/view_header.php' ?>
<body>
<div class="container-fluid">
	<center>
		<br>
	<h1>Warning</h1><br/>
	<h3>Anda harus login terlebih dahulu, untuk mengakses halaman ini!</h3>
	<a class="btn btn-primary" href="index.php">Login</a>
</center>
</div>
<?php include 'frontend/view_footer.php'; ?>