<?php
    class pegawai extends userData {
        
    }
?>