<?php
date_default_timezone_set("Asia/Jakarta");
$APP_NAME = "BAPAS SPPD APP";
$APP_VERSION = "1.0";
$DASHBOARD_TITLE = $APP_NAME."<sup>".$APP_VERSION;
$APP_PATH = "http://localhost/faroeeproject/BAPAS_WEB/";
?>