<?php
    include("frontend/view_header.php");
    include("frontend/view_body.php");
    include("frontend/view_footer.php");
?>